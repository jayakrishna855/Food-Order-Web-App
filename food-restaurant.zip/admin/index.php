<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<?php include("partials/menu.php"); ?>

<div class="main_content">
    <div class="wrapper">
        <h1>Dashboard</h1>
        <div class="col-4 text-center">
            <h1>5</h1>
            <br>
            Catergories
        </div>
        <div class="col-4 text-center">
            <h1>5</h1>
            <br>
            Catergories
        </div>
        <div class="col-4 text-center">
            <h1>5</h1>
            <br>
            Catergories

        </div>
        <div class="col-4 text-center">
            <h1>5</h1>
            <br>
            Catergories
        </div>
        <div class="clearfix">
        </div>

    </div>
</div>

<?php include("partials/footer.php");?>