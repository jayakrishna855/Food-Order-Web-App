<?php 
include('partials/menu.php');
?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Order</h1>
        <br>
    </div>
</div>

<?php 
include('partials/footer.php');
?>