<div class="footer">
            <div class="wrapper">
                <p class="text-center">2021  All rights reserved</p>

            </div>
        </div>
        
        
        
        <script src="" async defer></script>
    </body>
</html>